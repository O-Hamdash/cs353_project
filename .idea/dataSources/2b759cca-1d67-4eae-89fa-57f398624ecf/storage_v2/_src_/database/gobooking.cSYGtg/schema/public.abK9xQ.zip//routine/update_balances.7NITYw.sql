create function update_balances() returns trigger
    language plpgsql
as
$$
BEGIN
    -- Deduct booking cost from travelers' balance
    UPDATE app_user
    SET balance = balance - (SELECT cost
                             FROM pays
                             WHERE booking_id = NEW.booking_id)
    WHERE user_id = NEW.booker_id;

    -- Add booking cost to house owner's balance
    UPDATE app_user
    SET balance = balance + (SELECT cost
                             FROM pays
                             WHERE booking_id = NEW.booking_id)
    WHERE user_id = (SELECT property.owner_id
                     FROM property
                     WHERE property.property_id = NEW.property_id);

    RETURN NEW;
END;
$$;

alter function update_balances() owner to postgres;

