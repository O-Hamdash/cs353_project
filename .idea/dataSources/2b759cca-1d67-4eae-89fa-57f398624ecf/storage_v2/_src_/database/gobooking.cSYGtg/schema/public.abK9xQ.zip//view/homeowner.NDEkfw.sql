create view homeowner
            (user_id, balance, city, tax_number, registration_date, is_blocked, is_banned_from_booking,
             is_banned_from_posting) as
SELECT app_user.user_id,
       app_user.balance,
       app_user.city,
       app_user.tax_number,
       app_user.registration_date,
       app_user.is_blocked,
       app_user.is_banned_from_booking,
       app_user.is_banned_from_posting
FROM app_user
WHERE (EXISTS(SELECT property.property_id,
                     property.title,
                     property.status,
                     property.floor,
                     property.is_furnished,
                     property.description,
                     property.max_guests,
                     property.price_per_night,
                     property.owner_id,
                     property.location_id
              FROM property
              WHERE property.owner_id = app_user.user_id));

alter table homeowner
    owner to postgres;

