create function delete_reviews() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.is_blocked = true THEN
        DELETE FROM review WHERE reviewer_id = NEW.user_id;
    END IF;
    RETURN NEW;
END;
$$;

alter function delete_reviews() owner to postgres;

