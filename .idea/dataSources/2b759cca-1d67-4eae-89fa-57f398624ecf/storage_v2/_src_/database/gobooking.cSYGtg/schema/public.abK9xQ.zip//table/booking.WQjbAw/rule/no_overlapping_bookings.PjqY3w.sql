CREATE RULE no_overlapping_bookings AS
    ON INSERT TO booking
   WHERE (EXISTS ( SELECT b1.booking_id,
            b1.start_date,
            b1.end_date,
            b1.status,
            b1.booker_id,
            b1.property_id,
            b2.booking_id,
            b2.start_date,
            b2.end_date,
            b2.status,
            b2.booker_id,
            b2.property_id
           FROM booking b1,
            booking b2
          WHERE b1.booking_id <> b2.booking_id AND b1.property_id = b2.property_id AND b1.status::text <> 'cancelled'::text AND b2.status::text <> 'cancelled'::text AND (b1.start_date <= b2.start_date AND b1.end_date > b2.start_date OR b1.start_date >= b2.start_date AND b2.end_date > b1.start_date))) DO INSTEAD NOTHING;

